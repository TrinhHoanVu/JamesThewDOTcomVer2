import React from 'react'

function TipManagement() {
    return (
        <div>Tipmanagement</div>
    )
}

export default TipManagement