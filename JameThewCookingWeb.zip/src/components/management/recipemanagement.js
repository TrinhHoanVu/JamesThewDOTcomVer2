import React from 'react'

function RecipeManagement() {
    return (
        <div>RecipemanagemRnt</div>
    )
}

export default RecipeManagement