import React from 'react'

function PrivateContest() {
    return (
        <div>PrivateContest</div>
    )
}

export default PrivateContest